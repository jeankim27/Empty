## What changed

## Why
Source, analysis, or decision record. Link the issue: `Closes #`

## Checklist
- [ ] Design numbers changed only in `params/variables.yaml` (none typed into code, notebooks or docs)
- [ ] Every new or changed value has a `source` and the right `status`
- [ ] Changed a 🟢 frozen value? Linked a decision record in `docs/decisions/`
- [ ] New equation? Added to `docs/equations.md` and `tests/test_budget.py`
- [ ] Notebooks re-run top to bottom (outputs match the code)
- [ ] Checks pass (✅ below)
